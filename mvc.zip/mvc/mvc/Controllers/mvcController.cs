﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using mvc.Models;


namespace mvc.Controllers
{
    public class mvcController : Controller
    {
        //
        // GET: /mvc/

        public ActionResult mvcAction()
        {

            var m = new List<mvcclass>();
            SqlConnection con = null;
            SqlDataReader rdr = null;
            
            string result = "";
            try
            {
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["mycon"].ToString());
                SqlCommand cmd = new SqlCommand("SELECT * FROM tbInsertMobile", con);
                con.Open();

                // 1. get an instance of the SqlDataReader
                rdr = cmd.ExecuteReader();

                // print a set of column headers
                Console.WriteLine(
"Contact Name             City                Company Name");
                Console.WriteLine(
"------------             ------------        ------------");

                // 2. print necessary columns of each

                while (rdr.Read())
                {
                    mvcclass n = new mvcclass();
                    // get the results of each column
                    n.Account= (string)rdr["MobileName"];
                    n.Process = (string)rdr["MobileIMEno"];
                    n.Counts = (int)rdr["mobileprice"];
                    m.Add(n);
                   
                    // print out the results
                    Console.Write("{0,-25}", n.Account);
                    Console.Write("{0,-20}", n.Process);
                    Console.Write("{0,-25}", n.Counts);
                    Console.WriteLine();
                    /*cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@MobileID", 0);
                    // i will pass zero to MobileID beacause its Primary .
                    cmd.Parameters.AddWithValue("@MobileName", MD.MobileName);
                    cmd.Parameters.AddWithValue("@MobileIMEno", MD.MobileIMEno);
                    cmd.Parameters.AddWithValue("@mobileprice", MD.mobileprice);
                    cmd.Parameters.AddWithValue("@mobileManufacured", MD.mobileManufacured);
                    cmd.Parameters.AddWithValue("@Query", 1);
                    con.Open();
                    result = cmd.ExecuteScalar().ToString();
                    return result;*/
                }
               
                
            }
                catch(NullReferenceException ex)
            {
                    Console.Write(ex.Message);
                }
            catch
            {
                return View(m);
            }
                
            finally
            {
                con.Close();
            }
            
            return View();
        }
       

    }
}
